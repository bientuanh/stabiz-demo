import React from 'react';
import './Home.css'
const HomePage = ()=>{
    return(
    <div className="homepage">
        <h1>React training Post Application</h1>
        <img style={{width: '100%',height:'500px'}} src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/ef/4k-desktop-background_0652268559.jpg/1200px-4k-desktop-background_0652268559.jpg?20180626072247"/>
            <p> Lorem Ipsum is simply dummy text of the printing and typesetting industry.
        Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
            when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>
    </div>
    )
}
export default HomePage;