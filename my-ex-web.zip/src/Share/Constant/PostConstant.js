const PostConstant = {
    ID : 'ID',
    Title : 'Title',

    PageIndexDefault: 1,
    PageSizeDefault: 10,

    PostsListURL: `https://jsonplaceholder.typicode.com/posts/`,
}
export default PostConstant;