
const UserConstant = {
    Id: 'User Id',
    Name: 'Full Name',

    UserTokenURL: `https://60dff0ba6b689e001788c858.mockapi.io/tokens`,
    UserProfileURL:`https://60dff0ba6b689e001788c858.mockapi.io/users/`
}

export default UserConstant;